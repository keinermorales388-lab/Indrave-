# Compilar la APK usando solo el celular (GitHub Actions)

1. En el navegador del celular, entra a https://github.com y crea una cuenta/inicia sesión.
2. Crea un repositorio nuevo, por ejemplo `filtro-carreras-android`. Para una prueba, puedes elegir Private.
3. Descomprime `FiltroCarreras_Android_Pantalla_v0.2_GitHub.zip` con el gestor de archivos del teléfono.
4. Sube el CONTENIDO de la carpeta `indrivefilter` a la raíz del repositorio, incluyendo la carpeta oculta `.github/workflows`. Si la web móvil no permite subir carpetas completas, activa “Sitio para computadora” en el menú del navegador y sube los archivos/carpetas desde la web. No subas la carpeta `indrivefilter` como subcarpeta: `app`, `build.gradle.kts`, `settings.gradle.kts` y `.github` deben quedar en la raíz.
5. En GitHub, abre la pestaña Actions y confirma/activa los workflows si te lo pide. El flujo `Build APK` empieza al subir cambios a `main`/`master`; también puedes abrirlo y tocar `Run workflow`.
6. Cuando termine en verde, abre esa ejecución, baja hasta Artifacts y descarga `FiltroCarreras-debug-apk`.
7. Descomprime el artifact descargado. Dentro estará `app-debug.apk`. Tócalo para instalarlo y, si Android lo pide, permite temporalmente instalar aplicaciones desde tu navegador/gestor de archivos.

Notas:
- La compilación ocurre en los servidores de GitHub, no en el teléfono. Necesitas internet para subir el código y descargar el APK.
- Un APK debug es para pruebas; no es una versión firmada para distribución pública.
- No habilites Accesibilidad hasta que hayas revisado y confíes en la aplicación. Prueba la detección con cuidado: depende de qué texto exponga InDrive a Android.
