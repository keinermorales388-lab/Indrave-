package com.keiner.ridefilter

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlin.math.ceil

/** Optional best-effort automation. InDrive UI labels and accessible nodes vary by version. */
class RideScreenAccessibilityService : AccessibilityService() {
    private var lastActionKey = ""
    private var lastActionAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString().orEmpty().lowercase()
        if (!(pkg.contains("indriver") || pkg.contains("in_driver") || pkg.contains("sinet.startup"))) return
        val prefs = getSharedPreferences("filter_settings", MODE_PRIVATE)
        if (!prefs.getBoolean("automation_enabled", false)) return
        val root = rootInActiveWindow ?: return
        try {
            val nodes = mutableListOf<AccessibilityNodeInfo>()
            val text = StringBuilder()
            collect(root, text, nodes, 0)
            val screen = text.toString().lowercase()
            if (screen.isBlank()) return
            val fingerprint = screen.hashCode().toString()
            val now = System.currentTimeMillis()
            if (fingerprint == lastActionKey && now - lastActionAt < 12000L) return

            if (prefs.getBoolean("auto_accept", false) && looksSelected(screen)) {
                val accept = nodes.firstOrNull { n ->
                    val label = nodeLabel(n).lowercase().trim()
                    n.isEnabled && n.isClickable && (label == "aceptar" || label == "aceptar viaje" || label == "confirmar viaje")
                }
                if (accept != null && accept.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    markAction(fingerprint, now)
                    return
                }
            }

            if (prefs.getBoolean("auto_offer", false) && looksLikeOfferScreen(screen)) {
                val km = findTotalKm(screen)
                if (km != null && km > 0) {
                    val costKm = prefs.getString("cost_km", "350")?.toDoubleOrNull() ?: 350.0
                    val profitKm = prefs.getString("profit_km", "1500")?.toDoubleOrNull() ?: 1500.0
                    val extra = prefs.getString("fixed_cost", "0")?.toDoubleOrNull() ?: 0.0
                    val emptyKm = prefs.getString("return_distance", "0")?.toDoubleOrNull() ?: 0.0
                    val amount = ceil((km + emptyKm.coerceAtLeast(0.0)) * (costKm.coerceAtLeast(0.0) + profitKm.coerceAtLeast(0.0)) + extra.coerceAtLeast(0.0)).toLong()
                    val edit = nodes.firstOrNull { it.className?.toString()?.contains("EditText", true) == true && it.isEnabled }
                    val offerButton = nodes.firstOrNull { n ->
                        val label = nodeLabel(n).lowercase().trim()
                        n.isEnabled && n.isClickable && (label == "ofertar" || label == "hacer oferta" || label == "enviar oferta" || label == "proponer" || label == "proponer precio")
                    }
                    if (edit != null && offerButton != null) {
                        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, amount.toString()) }
                        if (edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
                            if (offerButton.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                                markAction(fingerprint, now)
                                return
                            }
                        }
                    }
                }
            }
            // Save the current accessible screen locally so the main app can show diagnostics.
            prefs.edit().putString("latest_text", text.toString().take(5000)).putString("latest_package", pkg).putLong("latest_time", now).apply()
        } finally {
            root.recycle()
        }
    }

    private fun looksSelected(screen: String): Boolean {
        val selected = listOf("te eligió", "te ha elegido", "te seleccionó", "te selecciono", "el pasajero te eligió", "pasajero te eligió")
        return selected.any { screen.contains(it) }
    }

    private fun looksLikeOfferScreen(screen: String): Boolean {
        val offerWords = listOf("tu oferta", "hacer oferta", "ofertar", "proponer precio", "oferta al pasajero", "oferta tu precio")
        return offerWords.any { screen.contains(it) }
    }

    private fun findTotalKm(screen: String): Double? {
        // Prefer explicitly-labelled distances. This remains a heuristic and may need adjustment for the app's exact screen.
        val matches = Regex("([0-9]+(?:[.,][0-9]+)?)\\s*km\\b", RegexOption.IGNORE_CASE).findAll(screen).mapNotNull {
            it.groupValues[1].replace(',', '.').toDoubleOrNull()
        }.toList()
        if (matches.isEmpty()) return null
        return matches.sum()
    }

    private fun nodeLabel(node: AccessibilityNodeInfo): String = buildString {
        node.text?.toString()?.let { append(it) }
        node.contentDescription?.toString()?.let { if (isNotEmpty()) append(' '); append(it) }
    }

    private fun collect(node: AccessibilityNodeInfo?, out: StringBuilder, nodes: MutableList<AccessibilityNodeInfo>, depth: Int) {
        if (node == null || depth > 35 || out.length > 5000) return
        nodes.add(node)
        nodeLabel(node).trim().takeIf { it.isNotEmpty() }?.let { label ->
            if (!out.contains(label)) out.append(label).append('\n')
        }
        for (i in 0 until node.childCount) collect(node.getChild(i), out, nodes, depth + 1)
    }

    private fun markAction(key: String, time: Long) {
        lastActionKey = key
        lastActionAt = time
        getSharedPreferences("filter_settings", MODE_PRIVATE).edit().putLong("last_automation_action", time).apply()
    }

    override fun onInterrupt() = Unit
}
