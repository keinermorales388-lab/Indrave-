package com.keiner.ridefilter

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.ceil

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("filter_settings", MODE_PRIVATE) }
    private val blue = Color.rgb(36, 91, 219)
    private val navy = Color.rgb(20, 32, 56)
    private val muted = Color.rgb(99, 112, 134)
    private val money = NumberFormat.getCurrencyInstance(Locale("es", "CO"))
    private lateinit var fare: EditText
    private lateinit var distance: EditText
    private lateinit var minutes: EditText
    private lateinit var returnDistance: EditText
    private lateinit var costKm: EditText
    private lateinit var profitKm: EditText
    private lateinit var profitHour: EditText
    private lateinit var fixedCost: EditText
    private lateinit var autoOffer: Switch
    private lateinit var autoAccept: Switch
    private lateinit var master: Switch
    private lateinit var result: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.rgb(246, 248, 252))
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(TextView(this).apply {
            text = "Filtro de Carreras"
            textSize = 27f; setTextColor(navy); setTypeface(null, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Tu filtro de rentabilidad para InDrive"
            textSize = 14f; setTextColor(muted); setPadding(0, dp(4), 0, dp(18))
        })

        val statusCard = card(root)
        statusCard.addView(TextView(this).apply {
            text = "AUTOMATIZACIÓN"
            textSize = 12f; setTextColor(muted); setTypeface(null, Typeface.BOLD)
        })
        master = Switch(this).apply {
            text = "Activar Filtro de Carreras"
            textSize = 17f; setTextColor(navy)
            isChecked = prefs.getBoolean("automation_enabled", false)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("automation_enabled", checked).apply()
                if (checked) {
                    Toast.makeText(this@MainActivity, "Activa el servicio de Accesibilidad si aún no lo has hecho.", Toast.LENGTH_LONG).show()
                } else Toast.makeText(this@MainActivity, "Automatización pausada", Toast.LENGTH_SHORT).show()
            }
        }
        statusCard.addView(master, params(top = 6))
        val access = actionButton("Configurar permiso de pantalla", blue) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        statusCard.addView(access, params(top = 8))
        statusCard.addView(TextView(this).apply {
            text = "Android requiere que habilites el servicio manualmente en Accesibilidad. La automatización solo funciona mientras el interruptor esté activo."
            textSize = 12f; setTextColor(muted); setPadding(0, dp(8), 0, 0)
        })

        val settingsCard = card(root, top = 14)
        settingsCard.addView(sectionTitle("Tus reglas de rentabilidad"))
        settingsCard.addView(TextView(this).apply {
            text = "Configura tus costos y la ganancia mínima. Los valores se guardan en este teléfono."
            textSize = 13f; setTextColor(muted); setPadding(0, dp(3), 0, dp(8))
        })
        fare = field(settingsCard, "Pago que muestra la oferta (COP)", "6500", "fare")
        distance = field(settingsCard, "Distancia total estimada (km)", "4.5", "distance")
        minutes = field(settingsCard, "Tiempo estimado total (min)", "18", "minutes")
        returnDistance = field(settingsCard, "Km adicionales sin pasajero", "1", "return_distance")
        costKm = field(settingsCard, "Gasolina + desgaste por km (COP)", "350", "cost_km")
        profitKm = field(settingsCard, "Ganancia neta mínima por km (COP)", "1500", "profit_km")
        profitHour = field(settingsCard, "Ganancia neta mínima por hora (COP)", "18000", "profit_hour")
        fixedCost = field(settingsCard, "Otros gastos por viaje (COP)", "0", "fixed_cost")

        val automationCard = card(root, top = 14)
        automationCard.addView(sectionTitle("Qué puede hacer automáticamente"))
        autoOffer = Switch(this).apply {
            text = "Calcular y enviar oferta"
            textSize = 15f; setTextColor(navy)
            isChecked = prefs.getBoolean("auto_offer", false)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("auto_offer", checked).apply() }
        }
        automationCard.addView(autoOffer, params(top = 4))
        autoAccept = Switch(this).apply {
            text = "Aceptar si el pasajero me elige"
            textSize = 15f; setTextColor(navy)
            isChecked = prefs.getBoolean("auto_accept", false)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("auto_accept", checked).apply() }
        }
        automationCard.addView(autoAccept, params(top = 4))
        automationCard.addView(TextView(this).apply {
            text = "Estas opciones vienen apagadas por seguridad. La compatibilidad depende de cómo InDrive muestre los botones y datos en tu versión. Revisa las primeras pruebas antes de trabajar con automatización."
            textSize = 12f; setTextColor(muted); setPadding(0, dp(8), 0, 0)
        })

        root.addView(actionButton("GUARDAR CONFIGURACIÓN", navy) { saveSettings(); Toast.makeText(this, "Configuración guardada", Toast.LENGTH_SHORT).show() }, params(top = 14))
        root.addView(actionButton("EVALUAR CARRERA DE PRUEBA", blue) { saveSettings(); evaluate() }, params(top = 8))
        val resultCard = card(root, top = 12)
        result = TextView(this).apply {
            text = "Aquí aparecerá el resultado de rentabilidad."
            textSize = 16f; setTextColor(navy); setPadding(dp(2), dp(2), dp(2), dp(2))
        }
        resultCard.addView(result)
        root.addView(TextView(this).apply {
            text = "Importante: Filtro de Carreras usa Accesibilidad para leer la pantalla activa de InDrive y, si activas las opciones, intentar interactuar con sus controles. Los cambios de interfaz pueden impedir la detección o causar una oferta incorrecta. No se garantiza compatibilidad hasta probarlo con ofertas reales."
            textSize = 12f; setTextColor(muted); setPadding(dp(2), dp(14), dp(2), 0)
        }, params(top = 8))
    }

    private fun card(root: LinearLayout, top: Int = 0): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(18).toFloat() }
            elevation = dp(2).toFloat()
        }
        root.addView(box, params(top = top, bottom = 2))
        return box
    }

    private fun sectionTitle(s: String) = TextView(this).apply {
        text = s; textSize = 18f; setTextColor(navy); setTypeface(null, Typeface.BOLD)
    }

    private fun actionButton(label: String, color: Int, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 15f; setTextColor(Color.WHITE); setBackgroundColor(color)
        setOnClickListener { action() }
    }

    private fun field(root: LinearLayout, label: String, fallback: String, key: String): EditText {
        root.addView(TextView(this).apply {
            text = label; textSize = 13f; setTextColor(navy); setPadding(0, dp(8), 0, dp(3))
        })
        val value = prefs.getString(key, fallback) ?: fallback
        val input = EditText(this).apply {
            setText(value); textSize = 16f; setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setPadding(dp(12), dp(7), dp(12), dp(7))
            background = GradientDrawable().apply { setColor(Color.rgb(247, 249, 253)); cornerRadius = dp(10).toFloat(); setStroke(dp(1), Color.rgb(220, 227, 238)) }
            tag = key
        }
        root.addView(input, params(bottom = 2))
        return input
    }

    private fun saveSettings() {
        prefs.edit()
            .putString("fare", fare.text.toString()).putString("distance", distance.text.toString())
            .putString("minutes", minutes.text.toString()).putString("return_distance", returnDistance.text.toString())
            .putString("cost_km", costKm.text.toString()).putString("profit_km", profitKm.text.toString())
            .putString("profit_hour", profitHour.text.toString()).putString("fixed_cost", fixedCost.text.toString())
            .putBoolean("automation_enabled", master.isChecked).putBoolean("auto_offer", autoOffer.isChecked)
            .putBoolean("auto_accept", autoAccept.isChecked).apply()
    }

    private fun evaluate() {
        val p = fare.num(); val km = distance.num(); val mins = minutes.num()
        val emptyKm = returnDistance.num(); val cost = costKm.num()
        val targetKm = profitKm.num(); val targetHour = profitHour.num(); val extra = fixedCost.num()
        if (p <= 0 || km <= 0 || mins <= 0) {
            result.text = "Revisa los datos: pago, distancia y tiempo deben ser mayores que cero."; return
        }
        val totalKm = km + emptyKm.coerceAtLeast(0.0)
        val expenses = totalKm * cost.coerceAtLeast(0.0) + extra.coerceAtLeast(0.0)
        val net = p - expenses
        val perKm = net / totalKm
        val perHour = net * 60.0 / mins
        val kmOk = perKm >= targetKm
        val hourOk = perHour >= targetHour
        val verdict = if (kmOk && hourOk) "BUENA RENTABILIDAD" else if (kmOk || hourOk) "REVISAR" else "BAJA RENTABILIDAD"
        result.text = "$verdict\n\nPago: ${money.format(p)}\nCostos estimados: ${money.format(expenses)}\nGanancia neta: ${money.format(net)}\nDistancia considerada: ${"%.1f".format(Locale.US, totalKm)} km\nNeto por km: ${money.format(perKm)}\nNeto por hora: ${money.format(perHour)}\n\nOferta mínima orientativa: ${money.format(ceil(totalKm * (cost.coerceAtLeast(0.0) + targetKm.coerceAtLeast(0.0)) + extra.coerceAtLeast(0.0)))}"
        result.setTextColor(if (kmOk && hourOk) Color.rgb(27, 110, 63) else if (kmOk || hourOk) Color.rgb(156, 93, 0) else Color.rgb(183, 38, 48))
    }

    private fun EditText.num(): Double = text.toString().trim().replace(",", ".").toDoubleOrNull() ?: 0.0
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun params(top: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(top), 0, dp(bottom)) }
}
