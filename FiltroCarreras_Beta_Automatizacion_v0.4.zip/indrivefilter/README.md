# Filtro de Carreras — versión beta de automatización

Aplicación Android nativa en Kotlin con una interfaz sencilla, reglas configurables de rentabilidad y un servicio opcional de Accesibilidad.

## Configuración
- Pago de referencia, kilómetros, tiempo, kilómetros adicionales sin pasajero.
- Costo por kilómetro (gasolina y desgaste), ganancia neta mínima por kilómetro, ganancia mínima por hora y otros gastos.
- Interruptor general para pausar o activar el servicio.
- Interruptores separados para intentar enviar ofertas y aceptar cuando la pantalla indique que el pasajero eligió al conductor. Ambos vienen apagados inicialmente.

## Cómo probar
1. Compila e instala el APK en el teléfono.
2. Abre Filtro de Carreras y configura los valores.
3. Toca **Configurar permiso de pantalla** y habilita el servicio de Accesibilidad.
4. Regresa a Filtro de Carreras y activa el interruptor general.
5. Primero prueba con **Calcular y enviar oferta** apagado para comprobar que la lectura de pantalla funciona. Después, si decides hacerlo, activa la oferta automática y prueba en una situación controlada. La aceptación automática es opcional y debe probarse por separado.

## Limitaciones importantes
Esta es una versión beta de mejor esfuerzo, no una integración oficial de InDrive. El servicio intenta localizar textos y controles accesibles con nombres habituales como “Ofertar” o “Aceptar viaje”. La interfaz, los nombres de botones y los datos accesibles pueden cambiar por versión, país o tipo de oferta. La detección de kilómetros y el importe calculado son heurísticos; si la pantalla no expone datos claros, la automatización no puede actuar correctamente. No se ha validado en una sesión real de InDrive y no debe asumirse que la oferta o aceptación automática ya funciona de forma fiable.

Antes de trabajar con ella, comprueba las ofertas manualmente y no dejes la aceptación automática activa hasta confirmar que identifica correctamente cada pantalla. Una carrera aceptada puede implicar compromisos reales y costos.

## Privacidad
La lectura ocurre localmente mediante el servicio de Accesibilidad. La app no necesita ubicación, contactos, micrófono ni cuenta de InDrive. Android requiere habilitar manualmente el permiso sensible de Accesibilidad.
