# Filtro de Carreras — Android

Proyecto Android nativo en Kotlin. La primera versión incluye una calculadora de rentabilidad y un lector opcional de texto visible mediante el servicio de Accesibilidad de Android.

## Qué hace la lectura de pantalla
- Solo se activa si el usuario la habilita manualmente en Ajustes > Accesibilidad.
- Intenta leer texto accesible de pantallas cuyo nombre de paquete coincide con patrones habituales de InDrive.
- Guarda localmente el último texto detectado y permite analizarlo desde la app.
- Intenta reconocer un precio y una distancia expresada en km, pero la detección es aproximada; revisa los campos antes de evaluar.
- No pulsa botones, no acepta ni rechaza carreras, no toma capturas de pantalla, no graba audio y no envía los datos a internet.

## Permisos y privacidad
No requiere permiso de ubicación, contactos, micrófono ni almacenamiento. Android exige declarar el servicio con `BIND_ACCESSIBILITY_SERVICE`; el usuario debe activarlo expresamente en Ajustes. Accesibilidad es un permiso sensible: explica al usuario qué lee y úsalo únicamente con consentimiento. Los datos de pantalla se guardan en preferencias locales privadas de la app.

## Limitaciones
- InDrive puede cambiar el nombre de su paquete, su interfaz o limitar los nodos accesibles. En ese caso el lector no detectará texto.
- El servicio solo ve texto que Android exponga mediante Accesibilidad. No puede leer de forma fiable texto dibujado como imagen, contenido protegido o interfaces no accesibles.
- La detección de precio/distancia es heurística y puede confundir números. Confirma todo manualmente.
- La app no automatiza ni altera InDrive, ni garantiza que una oferta se pueda evaluar antes de que desaparezca.

## Abrir y compilar
1. Instala Android Studio estable y un JDK compatible con la versión de Android Gradle Plugin que Android Studio resuelva.
2. Descomprime el ZIP y abre la carpeta `indrivefilter` en Android Studio.
3. Acepta instalar las herramientas SDK que solicite el IDE y espera a que Gradle termine de sincronizar.
4. Ejecuta primero en un teléfono Android conectado por USB (activa Opciones de desarrollador y Depuración USB) o en un emulador.
5. Para un APK de prueba: **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Normalmente queda en `app/build/outputs/apk/debug/app-debug.apk`.
6. Copia el APK al teléfono e instálalo. Si Android lo solicita, autoriza temporalmente la instalación desde esa fuente.
7. Abre Filtro de Carreras, toca **Activar lectura de pantalla**, elige el servicio y actívalo. Vuelve a InDrive, abre una oferta y regresa a la app para analizar el texto capturado.

## Antes de distribuir
Prueba en el modelo de teléfono y versión de InDrive que usarás. Para distribuir fuera de pruebas, genera un APK firmado desde **Build > Generate Signed Bundle / APK** y conserva la clave privada de firma. No publiques una compilación sin verificar la detección en pantallas reales.
