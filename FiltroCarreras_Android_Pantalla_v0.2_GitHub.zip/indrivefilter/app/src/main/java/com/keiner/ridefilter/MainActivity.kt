package com.keiner.ridefilter

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.ceil

class MainActivity : Activity() {
    private val blue = Color.rgb(21, 101, 192)
    private val ink = Color.rgb(24, 39, 56)
    private val money = NumberFormat.getCurrencyInstance(Locale("es", "CO"))

    private lateinit var fare: EditText
    private lateinit var distance: EditText
    private lateinit var minutes: EditText
    private lateinit var returnDistance: EditText
    private lateinit var fuelKm: EditText
    private lateinit var minPerKm: EditText
    private lateinit var minHourly: EditText
    private lateinit var fixedCost: EditText
    private lateinit var result: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(24))
            setBackgroundColor(Color.rgb(245, 248, 252))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(TextView(this).apply {
            text = "FILTRO DE CARRERAS"
            textSize = 24f; setTextColor(ink); setTypeface(null, 1)
        })
        root.addView(TextView(this).apply {
            text = "Evalúa rentabilidad y, si lo autorizas, lee texto visible de la pantalla de InDrive. Funciona sin internet."
            textSize = 14f; setTextColor(Color.DKGRAY); setPadding(0, dp(6), 0, dp(12))
        })
        val accessibilityButton = Button(this).apply {
            text = "ACTIVAR LECTURA DE PANTALLA"
            setTextColor(Color.WHITE); setBackgroundColor(blue)
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        root.addView(accessibilityButton, params(bottom = 6))
        val readButton = Button(this).apply {
            text = "ANALIZAR TEXTO CAPTURADO"
            setOnClickListener { loadCapturedOffer() }
        }
        root.addView(readButton, params(bottom = 10))
        val screenStatus = TextView(this).apply {
            text = "Lectura de pantalla: debes activarla manualmente en Ajustes > Accesibilidad."
            textSize = 12f; setTextColor(Color.DKGRAY); setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        root.addView(screenStatus, params(bottom = 12))

        fare = field(root, "Pago ofrecido (COP)", "6500")
        distance = field(root, "Distancia hasta recoger + recorrido (km)", "4.5")
        minutes = field(root, "Tiempo estimado total (minutos)", "18")
        returnDistance = field(root, "Km extra probables sin pasajero (0 si no aplica)", "1")
        fuelKm = field(root, "Costo de gasolina y desgaste por km (COP)", "350")
        minPerKm = field(root, "Ganancia mínima deseada por km (COP)", "1500")
        minHourly = field(root, "Ganancia mínima deseada por hora (COP)", "18000")
        fixedCost = field(root, "Otros costos del viaje (COP)", "0")

        val button = Button(this).apply {
            text = "EVALUAR CARRERA"
            setTextColor(Color.WHITE); setBackgroundColor(blue)
            setOnClickListener { evaluate() }
        }
        root.addView(button, params(top = 10, bottom = 10))
        result = TextView(this).apply {
            text = "Ingresa los datos de la oferta y toca Evaluar carrera."
            textSize = 16f; setTextColor(ink); setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(Color.WHITE)
        }
        root.addView(result, params(bottom = 14))
        root.addView(TextView(this).apply {
            text = "Privacidad y límites: el servicio solo examina el texto accesible de la ventana activa cuando está habilitado. No graba audio, no toma capturas, no pulsa botones ni acepta/rechaza viajes. Algunas pantallas de InDrive pueden no exponer sus datos a Accesibilidad; en ese caso introduce los datos manualmente. Verifica siempre destino, seguridad y condiciones reales."
            textSize = 12f; setTextColor(Color.DKGRAY); setPadding(0, dp(12), 0, 0)
        })
    }

    override fun onResume() {
        super.onResume()
        loadCapturedOffer(silent = true)
    }

    private fun loadCapturedOffer(silent: Boolean = false) {
        val prefs = getSharedPreferences("screen_capture", MODE_PRIVATE)
        val captured = prefs.getString("latest_text", "").orEmpty()
        val packageName = prefs.getString("latest_package", "").orEmpty()
        val timestamp = prefs.getLong("latest_time", 0L)
        if (captured.isBlank()) {
            if (!silent) Toast.makeText(this, "Todavía no hay texto capturado. Abre InDrive con la lectura habilitada.", Toast.LENGTH_LONG).show()
            return
        }
        // Best-effort parsing only. Never auto-accept/reject a trip.
        val moneyRegex = Regex("(?i)(?:COP\\s*)?\\$\\s*([0-9][0-9., ]{2,})|([0-9][0-9., ]{2,})\\s*(?:COP|pesos)")
        val fareMatch = moneyRegex.find(captured)
        val amountRaw = fareMatch?.groupValues?.drop(1)?.firstOrNull { it.isNotBlank() }
        val amount = amountRaw?.replace(" ", "")?.let { raw ->
            // Colombian fare notation commonly uses dots/commas as thousands separators.
            raw.replace(".", "").replace(",", "").toDoubleOrNull()
        }
        val kmMatch = Regex("(?i)([0-9]+(?:[.,][0-9]+)?)\\s*km\\b").find(captured)
        val km = kmMatch?.groupValues?.getOrNull(1)?.replace(",", ".")?.toDoubleOrNull()
        if (amount != null && amount > 0) fare.setText(amount.toLong().toString())
        if (km != null && km > 0) distance.setText(km.toString())
        result.text = "Texto leído desde: $packageName\n\n${captured.take(1800)}\n\nDetección automática orientativa: pago ${amount?.let { money.format(it) } ?: "no identificado"}; distancia ${km?.let { "${it} km" } ?: "no identificada"}. Revisa los campos antes de evaluar."
        result.setTextColor(ink)
        if (!silent) Toast.makeText(this, "Texto de pantalla analizado. Verifica los datos detectados.", Toast.LENGTH_LONG).show()
    }

    private fun field(root: LinearLayout, label: String, default: String): EditText {
        root.addView(TextView(this).apply {
            text = label; textSize = 14f; setTextColor(ink); setPadding(0, dp(8), 0, dp(3))
        })
        val input = EditText(this).apply {
            setText(default); textSize = 16f; singleLine = true
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setPadding(dp(12), dp(8), dp(12), dp(8)); setBackgroundColor(Color.WHITE)
        }
        root.addView(input, params())
        return input
    }

    private fun evaluate() {
        val p = fare.num(); val km = distance.num(); val mins = minutes.num()
        val emptyKm = returnDistance.num(); val costKm = fuelKm.num()
        val targetKm = minPerKm.num(); val targetHour = minHourly.num(); val extra = fixedCost.num()
        if (p <= 0 || km <= 0 || mins <= 0) {
            result.text = "Revisa los datos: pago, distancia y tiempo deben ser mayores que cero."
            return
        }
        val totalKm = km + emptyKm.coerceAtLeast(0.0)
        val expenses = totalKm * costKm.coerceAtLeast(0.0) + extra.coerceAtLeast(0.0)
        val net = p - expenses
        val perKm = if (totalKm > 0) net / totalKm else 0.0
        val perHour = net * 60.0 / mins
        val kmOk = perKm >= targetKm
        val hourOk = perHour >= targetHour
        val verdict = if (kmOk && hourOk) "ACEPTAR / BUENA OPCIÓN" else if (kmOk || hourOk) "REVISAR CON CUIDADO" else "RECHAZAR / POCO RENTABLE"
        val emoji = if (kmOk && hourOk) "✓" else if (kmOk || hourOk) "!" else "×"
        result.text = "$emoji  $verdict\n\nPago ofrecido: ${money.format(p)}\nCosto estimado: ${money.format(expenses)}\nGanancia neta estimada: ${money.format(net)}\nKm considerados: ${"%.1f".format(totalKm)} km\nGanancia neta por km: ${money.format(perKm)}\nGanancia neta por hora: ${money.format(perHour)}\n\nRegla: ${if (kmOk) "cumple" else "no cumple"} tu mínimo por km y ${if (hourOk) "cumple" else "no cumple"} tu mínimo por hora."
        result.setTextColor(if (kmOk && hourOk) Color.rgb(27, 94, 32) else if (kmOk || hourOk) Color.rgb(156, 86, 0) else Color.rgb(183, 28, 28))
    }

    private fun EditText.num(): Double = text.toString().trim().replace(",", ".").toDoubleOrNull() ?: 0.0
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun params(top: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        setMargins(0, dp(top), 0, dp(bottom))
    }
}
