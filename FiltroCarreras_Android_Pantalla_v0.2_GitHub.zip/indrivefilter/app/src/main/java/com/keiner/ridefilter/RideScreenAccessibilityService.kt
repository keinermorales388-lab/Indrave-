package com.keiner.ridefilter

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Opt-in, on-device text reader. It does not click, accept, reject, or automate rides. */
class RideScreenAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString().orEmpty()
        // Restrict collection to likely InDrive package names; package IDs can vary by region/version.
        val lower = pkg.lowercase()
        if (!(lower.contains("indriver") || lower.contains("in_driver") || lower.contains("sinet.startup"))) return
        val root = rootInActiveWindow ?: return
        val text = StringBuilder()
        collectText(root, text, 0)
        val content = text.toString().trim().replace(Regex("[ \t]+"), " ").take(6000)
        if (content.isNotBlank()) {
            getSharedPreferences("screen_capture", MODE_PRIVATE).edit()
                .putString("latest_text", content)
                .putString("latest_package", pkg)
                .putLong("latest_time", System.currentTimeMillis())
                .apply()
        }
        root.recycle()
    }

    private fun collectText(node: AccessibilityNodeInfo?, out: StringBuilder, depth: Int) {
        if (node == null || depth > 35 || out.length > 6000) return
        node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let {
            if (out.length == 0 || !out.contains(it)) out.append(it).append("\n")
        }
        node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let {
            if (out.length == 0 || !out.contains(it)) out.append(it).append("\n")
        }
        for (i in 0 until node.childCount) collectText(node.getChild(i), out, depth + 1)
    }

    override fun onInterrupt() = Unit
}
